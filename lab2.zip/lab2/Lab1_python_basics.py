import random

list_length = 15
random_list = [random.randint(1, 100) for _ in range(list_length)]
sum_of_evens = 0
for number in random_list:
    if number % 2 == 0:
        sum_of_evens += number

print(random_list)
print( sum_of_evens)
